package es.ieslosalbares.dam.ejemeplorest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemeploRestApplication {

    public static void main(String[] args) {
        SpringApplication.run(EjemeploRestApplication.class, args);
    }

}
