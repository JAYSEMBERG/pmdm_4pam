package es.ieslosalbares.dam.ejemeplorest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemeploRestApplicationTests {

    @Test
    void contextLoads() {
    }

}
